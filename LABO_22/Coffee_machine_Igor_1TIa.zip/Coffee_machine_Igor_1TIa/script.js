let global = {
    aantalBestellingen: 0
}


const setup = () => {
    let maakBtn = document.querySelector("#createBtn");
    maakBtn.addEventListener("click", maakKoffie);
}

const maakKoffie = () => {
    let tussenbericht = document.createElement("p");
    tussenbericht.textContent = "Je koffie wordt gemaakt!";

    let test = document.querySelector("#test")
    test.append(tussenbericht);

    tussenbericht.classList.add("tussenbericht");


    global.aantalBestellingen ++;
    voegBestellingToe();

    setTimeout(verwijderBericht, 2000);
    setTimeout(klaarBericht, 2000);
}
const verwijderBericht = () => {
    let tussenbericht = document.querySelector(".tussenbericht");

    document.querySelector("#test").removeChild(tussenbericht);
}

const klaarBericht = () => {
    let test = document.querySelector("#test");

    let span = document.createElement("span");
    span.classList.add("tussenbericht");


    span.textContent = "Je koffie is klaar!";
    test.append(span);


    test.removeChild(span);

}
const voegBestellingToe = () => {
    let bestellingen = document.querySelector("#atlBestellingen");
    voegOrderToe();
    bestellingen.textContent = global.aantalBestellingen + " bestellingen"
}
const voegOrderToe = () => {
    let options = document.querySelectorAll(".coffee");
    let orders = document.querySelector("#orders");


    let order = document.createElement("p");

    order.textContent = options[0].value
    let geen = document.querySelector("#geen");

    orders.removeChild(geen);

    orders.appendChild(order);

    if (options[0].selected){
        order.textContent = options[0].value
    }
}

window.addEventListener("load", setup);